############################################################################################################################
############################################################################################################################
###################                                                                                      ###################
###################                         Space Invaders 1.1 - 05/05/2014                              ###################
###################                                                                                      ###################
############################################################################################################################
############################################################################################################################

import pygame,sys
from pygame.locals import *
import random

############################################################################################################################

class Sprite:
        def __init__(self, xpos, ypos, filename):
                self.x = xpos
                self.y = ypos
                self.bitmap = pygame.image.load(filename)
                self.bitmap.set_colorkey((0,0,0))
        def set_position(self, xpos, ypos):
                self.x = xpos
                self.y = ypos
        def render(self):
                screen.blit(self.bitmap, (self.x, self.y))

def Intersect(s1_x, s1_y, s2_x, s2_y):
        if (s1_x > s2_x - 32) and (s1_x < s2_x + 32) and (s1_y > s2_y - 32) and (s1_y < s2_y + 32):
                return 1
        else:
                return 0

def Intersect2(s1_x, s1_y, s2_x, s2_y):
        if (s1_x > s2_x - 50) and (s1_x < s2_x + 50) and (s1_y > s2_y - 50) and (s1_y < s2_y + 50):
                return 1
        else:
                return 0

################################################ Définition des variables ##################################################
###################### et des images ainsi que de tout ce qui sera utilisé dans le reste du programme ######################

pygame.init()

mainclock= pygame.time.Clock()

screen = pygame.display.set_mode((900,600))
pygame.key.set_repeat(1, 1)
pygame.display.set_caption('Space Invaders 1.0')
backdrop = pygame.image.load('si_fond2.bmp')
backdrop2 = pygame.image.load('new-BG.bmp')
Texty = pygame.font.Font('si.ttf', 150)
Texty2 = pygame.font.Font('si.ttf', 200)
Texty3 = pygame.font.Font('si.ttf', 60)
Texty4 = pygame.font.Font('si.ttf', 20)
Texty5 = pygame.font.Font('si.ttf', 30)

hero = Sprite(420, 550, 'si_vaisseaufinal.bmp')
ourmissile = Sprite(20, 550, 'Missile 3.bmp')
enemymissile2 = Sprite(20, 550, 'Missile 2.bmp')
enemymissile = Sprite(20, 550, 'Missile 2.bmp')
shield2 = Sprite(20, 550, 'si_shield3.bmp')
shield3 = Sprite(20, 550, 'si_shield3.bmp')
shield4 = Sprite(20, 550, 'si_shield3.bmp')
bug = Sprite(20, 550, 'bug.bmp')
shipx=pygame.image.load('si_perso2.bmp')
shipy=pygame.image.load('si_perso3.bmp')

quitter = 0
enemyspeed = 2
enemyspeed2 = 2

pygame.mixer.init()
pygame.mixer.music.load("si_music.wav")
pygame.mixer.music.play()

pew = pygame.mixer.Sound("si_pew.wav")
gameover = pygame.mixer.Sound("si_gameover.wav")

enemies = []
enemies2 = []

x = 0
n2 = 0
n3 = 0
n4 = 0

shield2.x = 100
shield2.y = 510
shield3.x = 410
shield3.y = 510
shield4.x = 700
shield4.y = 510

bug.x = 50
bug.y = 510

menu = True
game = False
option=0
easter=0

###################################### Boucle du menu (en attente d'évènements) ############################################

while True:
        screen.blit(backdrop2, (0, 0))
        text7=Texty.render('Space Invaders', 0, (160,160,255))
        screen.blit(text7, (83,3))
        text=Texty.render('Space Invaders', 0, (0,0,255))
        screen.blit(text, (80,0))
        text2=Texty3.render('Jouer', 0, (0,255,0))
        screen.blit(text2, (410,200))
        text3=Texty3.render('Quitter', 0, (0,255,0))
        screen.blit(text3, (410,300))
        text3=Texty3.render('Version finale 1.0', 0, (255,0,0))
        screen.blit(text3, (270,500))
        text4=Texty4.render('Musique sous licence Creative Commons - SmallRadio : LSF 7th Gear Remix', 0, (255,255,0))
        screen.blit(text4, (200,580))
        text5=Texty4.render('Jeu conçu par Levent-Gabriel Bayrakli, Sevan Garois et Charles Picot', 0, (255,255,0))
        screen.blit(text5, (216,550))
        text6=Texty4.render("L'intégralité du programme (musique non comprise) est sous licence Copyright", 0, (50,226,103))
        screen.blit(text6, (190,565))
        text8=Texty5.render('Appuyez sur Entrée', 0, (255,255,255))
        screen.blit(text8, (355,488))

        pygame.display.update()
        while game == False:
                player=pygame.Rect(170,380,20,20)
                pygame.display.update()
                quitter = 0
                enemyspeed = 2
                enemyspeed2 = 2
                for event in pygame.event.get():
                        if event.type==QUIT:
                                pygame.quit()
                                sys.exit()
                        if event.type== KEYDOWN:
                                if event.key== K_DOWN and option==0:
                                        option=option+1
                                if event.key==K_UP and option==1:
                                        option=option-1
                                if event.key==K_RETURN and option==1 or event.key==K_RIGHT and option==1:
                                        pygame.quit()
                                        sys.exit()
                                if event.key==K_RETURN and option==0 or event.key==K_RIGHT and option==0:
                                        game=True
                                if event.key==K_h:
                                        text9=Texty5.render('Déplacez vous avec haut et bas, validez avec entrée ou droite', 0, (150,150,255))
                                        screen.blit(text9, (110,130))

                if option==0:
                    screen.blit(shipx,(player.left+180,player.top-172))
                    screen.blit(shipy,(350,308))
                    pygame.display.update()
                if option==1:
                    screen.blit(shipx,(player.left+180,player.top-72))
                    screen.blit(shipy, (350,208))
                    pygame.display.update()

############################################# "Si on lance le jeu alors" ###################################################

        while game == True :
                for count in range(1):
                        enemies.append(Sprite(50 * x + 50, 50, 'si_perso2.bmp'))
                        enemies2.append(Sprite(50 * x + 50, 90, 'si_perso2.bmp'))
                        x += 1

                while quitter == 0:
                        screen.blit(backdrop, (0, 0))
                        
                        for count in range(len(enemies)):
                                enemies[count].x += + enemyspeed
                                enemies[count].render()

                        for count in range(len(enemies2)):
                                enemies2[count].x += + enemyspeed2
                                enemies2[count].render()

#################################### Condition de collision sur les bords de l'écran ######################################
                        if (len(enemies))>0:  
                                if enemies[len(enemies)-1].x > 840:
                                        enemyspeed = -2
                                        #print(len(enemies)-1) Ici uniquement pour du debugage
                                        for count in range(len(enemies)):
                                                enemies[count].y += 5
                                if enemies[0].x < 10:
                                        enemyspeed = 2
                                        for count in range(len(enemies)):
                                                enemies[count].y += 5

                        if (len(enemies2))>0:
                                if enemies2[len(enemies2)-1].x > 840:
                                        enemyspeed2 = -2
                                        #print(len(enemies2)-1) Debugage
                                        for count in range(len(enemies2)):
                                                enemies2[count].y += 5
                                if enemies2[0].x < 10:
                                        enemyspeed2 = 2
                                        for count in range(len(enemies2)):
                                                enemies2[count].y += 5                        

#################################### Condition d'apparition des missiles ###################################################

                        if ourmissile.y < 840 and ourmissile.y > 0:
                                ourmissile.render()
                                ourmissile.y -= 7

                        if enemymissile.y >= 580 and len(enemies) > 0:
                                enemymissile.x = enemies[random.randint(0, len(enemies) - 1)].x
                                enemymissile.y = enemies[0].y

                        if enemymissile2.y >= 580 and len(enemies2) > 0:
                                enemymissile2.x = enemies2[random.randint(0, len(enemies2) - 1)].x
                                enemymissile2.y = enemies2[0].y

###################################### Intersection missile ennemi avec les shields ########################################

                        if Intersect2(shield2.x+37, shield2.y+20, enemymissile.x, enemymissile.y):
                                "Si shield touché alors :"
                                enemymissile.y = enemymissile.y + 1000
                                n2 = n2 + 1
                                if n2 == 4 :
                                        shield2.y = shield2.y+1000                
                                
                        if Intersect2(shield2.x+37, shield2.y+20, enemymissile2.x, enemymissile2.y):
                                "Si shield touché alors :"
                                enemymissile2.y = enemymissile2.y + 1000
                                n2 = n2 + 1
                                if n2 == 4 :
                                        shield2.y = shield2.y+1000

                        if Intersect2(shield3.x+37, shield3.y+20, enemymissile.x, enemymissile.y):
                                "Si shield touché alors :"
                                enemymissile.y = enemymissile.y + 1000
                                n3 = n3 + 1
                                if n3 == 4 :
                                        shield3.y = shield3.y+1000
                                                                
                        if Intersect2(shield3.x+37, shield3.y+20, enemymissile2.x, enemymissile2.y):
                                "Si shield touché alors :"
                                enemymissile2.y = enemymissile2.y + 1000
                                n3 = n3 + 1
                                if n3 == 4 :
                                        shield3.y = shield3.y+1000
                                

                        if Intersect2(shield4.x+37, shield4.y+20, enemymissile.x, enemymissile.y):
                                "Si shield touché alors :"
                                enemymissile.y = enemymissile.y + 1000
                                n4 = n4 + 1
                                if n4 == 4 :
                                        shield4.y = shield4.y+1000
                                
                                
                        if Intersect2(shield4.x+37, shield4.y+20, enemymissile2.x, enemymissile2.y):
                                "Si shield touché alors :"
                                enemymissile2.y = enemymissile2.y + 1000
                                n4 = n4 + 1
                                if n4 == 4 :
                                        shield4.y = shield4.y+1000

################################## Intersection de notre missile et des shields + bug ######################################

                        if Intersect2(shield2.x+37, shield2.y, ourmissile.x, ourmissile.y):
                                "Si shield touché par notre missile alors :"
                                ourmissile.y = ourmissile.y + 1000

                        if Intersect2(shield3.x+37, shield3.y, ourmissile.x, ourmissile.y):
                                "Si shield touché par notre missile alors :"
                                ourmissile.y = ourmissile.y + 1000

                        if Intersect2(shield4.x+37, shield4.y, ourmissile.x, ourmissile.y):
                                "Si shield touché par notre missile alors :"
                                ourmissile.y = ourmissile.y + 1000

                        if Intersect(bug.x, bug.y, ourmissile.x, ourmissile.y):
                                "Création d'une hitbox temporaire pour parer au bug du premier missile"
                                ourmissile.y = ourmissile.y + 1000
                                bug.y = bug.y + 1000

########################################### Intersection missile ennemi et du vaisseau #####################################
                        if Intersect(hero.x+20, hero.y+13, enemymissile.x, enemymissile.y):
                                "Si héros touché alors :"
                                text = Texty2.render('Game Over', 0, (255,0,0))
                                screen.blit(text, (120,150))
                                gameover.play()
                                pygame.display.update()
                                pygame.time.delay(1000)
                                pygame.time.delay(500)
                                del text
                                del enemies
                                del enemies2
                                enemymissile.y=enemymissile.y+1000
                                hero.x=410
                                enemies = []
                                enemies2 = []
                                quitter=1
                                x=0
                                n2 = 0
                                n3 = 0
                                n4 = 0
                                game = False
                        
                        if Intersect(hero.x+20, hero.y+13, enemymissile2.x, enemymissile2.y):
                                "Si héros touché alors :"
                                text = Texty2.render('Game Over', 0, (255,0,0))
                                screen.blit(text, (120,150))
                                gameover.play()
                                pygame.display.update()
                                pygame.time.delay(1000)
                                pygame.time.delay(500)
                                del text
                                del enemies
                                del enemies2
                                enemymissile2.y=enemymissile2.y+1000
                                hero.x=410
                                enemies = []
                                enemies2 = []
                                quitter=1
                                x=0
                                n2 = 0
                                n3 = 0
                                n4 = 0
                                game = False
                                
#################### Condition de disparition de notre missile en cas d'intersection avec un ennemi ########################
                                
                        for count in range(0, len(enemies)):
                                "Si notre missile rencontre un ennemi alors :"
                                if Intersect(ourmissile.x, ourmissile.y, enemies[count].x, enemies[count].y):
                                        del enemies[count]
                                        ourmissile.y=ourmissile.y-1000
                                        break

                        for count in range(0, len(enemies2)):
                                "Si notre missile rencontre un ennemi alors :"
                                if Intersect(ourmissile.x, ourmissile.y, enemies2[count].x, enemies2[count].y):
                                        del enemies2[count]
                                        ourmissile.y=ourmissile.y-1000
                                        break

################# Condition de "si plus d'ennemis alors", alors que le jeu n'est pas arreté #################################

                        if game == True:
                                if len(enemies) == 0 and len(enemies2) == 0:
                                        "Si plus d'ennemis alors :"
                                        textx = Texty2.render('Good Game', 0, (255,0,0))
                                        screen.blit(textx, (120,150))
                                        pygame.display.update()
                                        pygame.time.delay(1000)
                                        pygame.time.delay(500)
                                        quitter = 1
                                        enemymissile.y=enemymissile2.y+1000
                                        enemymissile2.y=enemymissile2.y+1000
                                        hero.x=410
                                        game = False

############################# Boucle principale du jeu (en attente d'évènements définis précédemment) ######################


                        for ourevent in pygame.event.get():
                                if ourevent.type == QUIT:
                                        quitter = 1
                                if ourevent.type == KEYDOWN:
                                        if ourevent.key == K_RIGHT and hero.x < 820:
                                                hero.x += 5
                                        if ourevent.key == K_LEFT and hero.x > 10:
                                                hero.x -= 5
                                        if ourevent.key == K_SPACE:
                                                ourmissile.x = hero.x+27
                                                ourmissile.y = hero.y
                                                pew.play()
                                        if ourevent.key == K_ESCAPE:
                                                quitter = 1
                                                del enemies
                                                del enemies2
                                                enemies = []
                                                enemies2 = []
                                                x=0
                                                n2=0
                                                n3=0
                                                n4=0
                                                hero.x=410
                                                game = False

############################################# Affichage des éléments du jeu ################################################

                        shield2.render()
                        shield3.render()
                        shield4.render()
                        enemymissile.render()
                        enemymissile.y += 5
                        enemymissile2.render()
                        enemymissile2.y += 5
                        hero.render()
                        pygame.display.update()
                        pygame.time.delay(5)
                        mainclock.tick(60)
